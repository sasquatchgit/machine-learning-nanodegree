import random
from environment import Agent, Environment
from planner import RoutePlanner
from simulator import Simulator

class LearningAgent(Agent):
    """An agent that learns to drive in the smartcab world."""

    def __init__(self, env):
        super(LearningAgent, self).__init__(env)  # sets self.env = env, state = None, next_waypoint = None, and a default color
        self.color = 'red'  # override color
        self.planner = RoutePlanner(self.env, self)  # simple route planner to get next_waypoint
        # TODO: Initialize any additional variables here
        actions_param = (None, 'forward', 'left', 'right')

        self.qLearner = QLearner(actions_param)
        number_of_steps = []
        self.penalty_count = 0

    def reset(self, destination=None):
        self.planner.route_to(destination)
        # TODO: Prepare for a new trip; reset any variables here, if required
        # self.penalty_count = 0

    def update(self, t):
        # Gather inputs
        self.next_waypoint = self.planner.next_waypoint()  # from route planner, also displayed by simulator
        inputs = self.env.sense(self)
        deadline = self.env.get_deadline(self)

        # TODO: Update state
        # self.state = (inputs, self.next_waypoint) # Question 2
        inputs_arr = inputs.items()
        self.state = (inputs_arr[0], inputs_arr[1], inputs_arr[3], self.next_waypoint) # taking light, oncoming, left and next_waypoint as final states for QLearner


        # print "state: " + str(self.state)
        
        # TODO: Select action according to your policy
        # action = random.choice(Environment.valid_actions) # for question 1
        action = self.qLearner.select_action(self.state)


        # Execute action and get reward
        reward = self.env.act(self, action)

        if reward < 0:
        	print "reward : " + str(reward)
        	self.penalty_count += 1
        	print "penalty count : " + str(self.penalty_count)

        # TODO: Learn policy based on state, action, reward
        inputs_new = self.env.sense(self)
        inputs_new_arr = inputs_new.items()

        state_new = (inputs_arr[0], inputs_new_arr[1], inputs_new_arr[3], self.next_waypoint)
        self.qLearner.learn(self.state, state_new, action, reward)

        # print "LearningAgent.update(): deadline = {}, inputs = {}, action = {}, reward = {}".format(deadline, inputs, action, reward)  # [debug]

#The implemented QLearner
class QLearner():
    def __init__(self, actions, alpha=0.35, gamma=0.20, epsilon=0.05):
        self.q = {}
        self.all_actions = actions
        self.alpha = alpha #reward multiplier
        self.gamma = gamma #delayed reward discount multiplier
        self.epsilon = epsilon #amount of randomness for action

        # print epsilon
        
    def select_action(self, state):
        if random.random() < self.epsilon:
            action = random.choice(self.all_actions) #select random action
        else:
            # select the best available action
            q = [self.get_q(state, a) for a in self.all_actions]
            max_q = max(q)

            if q.count(max_q) > 1:
                best = [i for i in range(len(self.all_actions)) if q[i] == max_q]
                i = random.choice(best)
            else:
                i = q.index(max_q)
                
            action = self.all_actions[i]

        return action

    def learn_q(self, state, action, reward, value):
        old_value = self.q.get((state, action), None)
        if old_value == None:
            new_value = reward
        else:
            new_value = old_value + self.alpha * (value - old_value)

        self.set_q(state, action, new_value) #update table

    def learn(self, state, new_state, action, reward):
        q = [self.get_q(new_state, a) for a in self.all_actions]
        delayed_reward = int(max(q))
        
        self.learn_q(state, action, reward, reward - self.gamma * delayed_reward)

    #get table value with key
    def get_q(self, state, action):
        return self.q.get((state, action), 0.0)

    #set table value at key
    def set_q(self, state, action, q):
        self.q[(state, action)] = q




def run():
    """Run the agent for a finite number of trials."""

    # Set up environment and agent
    e = Environment()  # create environment (also adds some dummy traffic)
    a = e.create_agent(LearningAgent)  # create agent
    e.set_primary_agent(a, enforce_deadline=True)  # specify agent to track
    # NOTE: You can set enforce_deadline=False while debugging to allow longer trials

    # Now simulate it
    sim = Simulator(e, update_delay=0.1, display=False)  # create simulator (uses pygame when display=True, if available)
    # NOTE: To speed up simulation, reduce update_delay and/or set display=False

    sim.run(n_trials=100)  # run for a specified number of trials
    # NOTE: To quit midway, press Esc or close pygame window, or hit Ctrl+C on the command-line


if __name__ == '__main__':
    run()
